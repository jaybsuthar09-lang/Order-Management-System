import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, customers, products, orders, orderItems, company } from "../drizzle/schema";
import { desc, like, and, or } from "drizzle-orm";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * CUSTOMER QUERIES
 */
export async function getCustomers(searchTerm?: string) {
  const db = await getDb();
  if (!db) return [];

  if (searchTerm) {
    return await db
      .select()
      .from(customers)
      .where(
        or(
          like(customers.name, `%${searchTerm}%`),
          like(customers.companyName, `%${searchTerm}%`),
          like(customers.email, `%${searchTerm}%`)
        )
      )
      .orderBy(desc(customers.createdAt));
  }

  return await db.select().from(customers).orderBy(desc(customers.createdAt));
}

export async function getCustomerById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createCustomer(data: typeof customers.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(customers).values(data);
  return result;
}

export async function updateCustomer(id: number, data: Partial<typeof customers.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(customers).set(data).where(eq(customers.id, id));
}

export async function deleteCustomer(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(customers).where(eq(customers.id, id));
}

/**
 * PRODUCT QUERIES
 */
export async function getProducts(searchTerm?: string) {
  const db = await getDb();
  if (!db) return [];

  if (searchTerm) {
    return await db
      .select()
      .from(products)
      .where(
        or(
          like(products.name, `%${searchTerm}%`),
          like(products.category, `%${searchTerm}%`),
          like(products.hsn, `%${searchTerm}%`)
        )
      )
      .orderBy(desc(products.createdAt));
  }

  return await db.select().from(products).orderBy(desc(products.createdAt));
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createProduct(data: typeof products.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(products).values(data);
}

export async function updateProduct(id: number, data: Partial<typeof products.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(products).where(eq(products.id, id));
}

/**
 * COMPANY QUERIES
 */
export async function getCompanySettings() {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(company).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateCompanySettings(data: Partial<typeof company.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getCompanySettings();
  if (existing) {
    return await db.update(company).set(data).where(eq(company.id, existing.id));
  } else {
    return await db.insert(company).values(data as typeof company.$inferInsert);
  }
}

/**
 * ORDER QUERIES
 */
export async function getOrders(searchTerm?: string) {
  const db = await getDb();
  if (!db) return [];

  if (searchTerm) {
    return await db
      .select()
      .from(orders)
      .where(like(orders.deliveryNumber, `%${searchTerm}%`))
      .orderBy(desc(orders.createdAt));
  }

  return await db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getOrderByDeliveryNumber(deliveryNumber: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(orders).where(eq(orders.deliveryNumber, deliveryNumber)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createOrder(data: typeof orders.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(orders).values(data);
}

export async function updateOrder(id: number, data: Partial<typeof orders.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(orders).set(data).where(eq(orders.id, id));
}

export async function deleteOrder(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(orders).where(eq(orders.id, id));
}

/**
 * ORDER ITEMS QUERIES
 */
export async function getOrderItems(orderId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
}

export async function createOrderItem(data: typeof orderItems.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(orderItems).values(data);
}

export async function deleteOrderItem(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(orderItems).where(eq(orderItems.id, id));
}

/**
 * DELIVERY NUMBER GENERATOR
 */
export async function generateDeliveryNumber() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const lastOrder = await db.select().from(orders).orderBy(desc(orders.id)).limit(1);
  const nextNumber = (lastOrder.length > 0 ? parseInt(lastOrder[0].deliveryNumber.split("-")[2]) : 0) + 1;
  return `DM-2026-${String(nextNumber).padStart(6, "0")}`;
}
